<?php


namespace App\Http\Controllers;

use Exception;
use Illuminate\View\View;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;

class PaymentTransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index() : View|RedirectResponse
    {
        try {

            return view('admin.payment_transactions.index');

        } catch (Exception $e) {

            info('Error showing Payment Transactions!', [$e]);

            return redirect()->back()->with('error', 'Payment Transactions showing failed!.');

        }
    }

    /**
     * Show the specified resource.
     *
     * @param  Payment Transactions $singularTableName
     * @return \Illuminate\View\View
     */

    public function create() : View|RedirectResponse
    {
        try {

            return view('admin.payment_transactions.create');

        } catch (Exception $e) {

            info('Error showing Payment Transactions!', [$e]);

            return redirect()->back()->with('error', 'Payment Transactions showing failed!.');

        }
    }

     /**
     * Edit the specified resource.
     *
     * @param  Request $request
     * @param  Payment Transactions $singularTableName
     * @return \Illuminate\View\View
     */

     public function edit() : View|RedirectResponse
    {
        try {

            return view('admin.payment_transactions.edit');

        } catch (Exception $e) {

            info('Error showing Payment Transactions!', [$e]);

            return redirect()->back()->with('error', 'Payment Transactions showing failed!.');

        }
    }


    /**
     * Display the specified resource.
     *
     * @return \Illuminate\View\View
     */
    public function show() : View|RedirectResponse
    {
        try {

            return view('admin.payment_transactions.view');

        } catch (\Exception $e) {

            info('Payment Transactions data showing failed!', [$e]);

            return redirect()->back()->with('error', 'Payment Transactions showing failed!.');
        }
    }

}
