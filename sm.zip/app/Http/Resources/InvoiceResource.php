<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use App\Http\Resources\BaseResource;

class InvoiceResource extends BaseResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'user_id_details' => $this->User,
            'user_name' => $this->User?->name ?? $this->User?->title ?? $this->User?->code ?? null,
            'subscription_id' => $this->subscription_id,
            'subscription_id_details' => $this->Subscription,
            'subscription_name' => $this->Subscription?->name ?? $this->Subscription?->title ?? $this->Subscription?->code ?? null,
            'number' => $this->number,
            'external_id' => $this->external_id,
            'type' => $this->type,
            'status' => $this->status,
            'subtotal' => $this->subtotal ? (float) $this->subtotal : 0.0,
            'tax' => $this->tax ? (float) $this->tax : 0.0,
            'total' => $this->total ? (float) $this->total : 0.0,
            'amount_due' => $this->amount_due ? (float) $this->amount_due : 0.0,
            'amount_paid' => $this->amount_paid ? (float) $this->amount_paid : 0.0,
            'amount_remaining' => $this->amount_remaining ? (float) $this->amount_remaining : 0.0,
            'currency' => $this->currency,
            'issue_date' => $this->issue_date?->format('Y-m-d H:i:s'),
            'due_date' => $this->due_date?->format('Y-m-d H:i:s'),
            'paid_at' => $this->paid_at?->format('Y-m-d H:i:s'),
            'finalized_at' => $this->finalized_at?->format('Y-m-d H:i:s'),
            'line_items' => $this->line_items ? json_decode($this->line_items, true) : [],
            'tax_rates' => $this->tax_rates ? json_decode($this->tax_rates, true) : [],
            'discounts' => $this->discounts ? json_decode($this->discounts, true) : [],
            'metadata' => $this->metadata ? json_decode($this->metadata, true) : [],
            'history' => $this->history ? json_decode($this->history, true) : [],
            'pdf_url' => $this->pdf_url,
            'created_at' => $this->created_at?->format('Y-m-d H:i:s'),
            'updated_at' => $this->updated_at?->format('Y-m-d H:i:s'),
            'created_at_formatted' => $this->created_at?->format('M d, Y h:i A'),
            'updated_at_formatted' => $this->updated_at?->format('M d, Y h:i A'),
            'created_at_human' => $this->created_at?->diffForHumans(),
            'updated_at_human' => $this->updated_at?->diffForHumans()
        ];
    }
}