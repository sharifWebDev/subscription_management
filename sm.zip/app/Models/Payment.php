<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Payment extends Model
{
    use HasFactory;
        protected $table = 'payments';
        protected $fillable = ['invoice_id', 'user_id', 'external_id', 'type', 'status', 'amount', 'fee', 'net', 'currency', 'gateway', 'gateway_response', 'payment_method', 'processed_at', 'refunded_at', 'metadata', 'fraud_indicators', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function invoice()
    {
        return $this->belongsTo(\App\Models\Invoice::class, 'invoice_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}