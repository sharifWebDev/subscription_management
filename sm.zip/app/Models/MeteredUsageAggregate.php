<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MeteredUsageAggregate extends Model
{
    use HasFactory;
        protected $table = 'metered_usage_aggregates';
        protected $fillable = ['subscription_id', 'feature_id', 'aggregate_date', 'aggregate_period', 'total_quantity', 'tier1_quantity', 'tier2_quantity', 'tier3_quantity', 'total_amount', 'record_count', 'last_calculated_at', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function subscription()
    {
        return $this->belongsTo(\App\Models\Subscription::class, 'subscription_id');
    }

    public function feature()
    {
        return $this->belongsTo(\App\Models\Feature::class, 'feature_id');
    }
}