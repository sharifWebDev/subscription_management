<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Discount extends Model
{
    use HasFactory;
        protected $table = 'discounts';
        protected $fillable = ['code', 'name', 'type', 'amount', 'currency', 'applies_to', 'applies_to_ids', 'max_redemptions', 'times_redeemed', 'is_active', 'starts_at', 'expires_at', 'duration', 'duration_in_months', 'metadata', 'restrictions', 'created_by', 'updated_by'];

    //handleFileUpload
    
}