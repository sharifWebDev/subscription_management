<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PaymentMaster extends Model
{
    use HasFactory;
        protected $table = 'payment_masters';
        protected $fillable = ['user_id', 'payment_number', 'type', 'status', 'total_amount', 'subtotal', 'tax_amount', 'discount_amount', 'fee_amount', 'net_amount', 'paid_amount', 'due_amount', 'currency', 'exchange_rate', 'base_currency', 'base_amount', 'payment_method', 'payment_method_details', 'payment_gateway', 'is_installment', 'installment_count', 'installment_frequency', 'payment_date', 'due_date', 'paid_at', 'cancelled_at', 'expires_at', 'customer_reference', 'bank_reference', 'gateway_reference', 'metadata', 'custom_fields', 'notes', 'failure_reason', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function paymentTransactions()
    {
        return $this->hasMany(\App\Models\PaymentTransaction::class, 'payment_master_id');
    }

    public function refunds()
    {
        return $this->hasMany(\App\Models\Refund::class, 'payment_master_id');
    }

    public function subscriptionOrders()
    {
        return $this->hasMany(\App\Models\SubscriptionOrder::class, 'payment_master_id');
    }
}