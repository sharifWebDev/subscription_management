<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Subscription extends Model
{
    use HasFactory;
        protected $table = 'subscriptions';
        protected $fillable = ['user_id', 'plan_id', 'plan_price_id', 'parent_subscription_id', 'status', 'billing_cycle_anchor', 'quantity', 'unit_price', 'amount', 'currency', 'trial_starts_at', 'trial_ends_at', 'trial_converted', 'current_period_starts_at', 'current_period_ends_at', 'billing_cycle_anchor_date', 'canceled_at', 'cancellation_reason', 'prorate', 'proration_amount', 'proration_date', 'gateway', 'gateway_subscription_id', 'gateway_customer_id', 'gateway_metadata', 'metadata', 'history', 'created_by', 'updated_by', 'is_active'];

    //handleFileUpload
    


public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function plan()
    {
        return $this->belongsTo(\App\Models\Plan::class, 'plan_id');
    }

    public function planPrice()
    {
        return $this->belongsTo(\App\Models\PlanPrice::class, 'plan_price_id');
    }

    public function usageRecords()
    {
        return $this->hasMany(\App\Models\UsageRecord::class, 'subscription_id');
    }
}