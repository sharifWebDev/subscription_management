<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PaymentGateway extends Model
{
    use HasFactory;
        protected $table = 'payment_gateways';
        protected $fillable = ['name', 'code', 'type', 'is_active', 'is_test_mode', 'supports_recurring', 'supports_refunds', 'supports_installments', 'api_key', 'api_secret', 'webhook_secret', 'merchant_id', 'store_id', 'store_password', 'base_url', 'callback_url', 'webhook_url', 'supported_currencies', 'supported_countries', 'excluded_countries', 'percentage_fee', 'fixed_fee', 'fee_currency', 'fee_structure', 'config', 'metadata', 'settlement_days', 'refund_days', 'min_amount', 'max_amount', 'created_by', 'updated_by'];

    //handleFileUpload
    

    public function paymentWebhookLogs()
    {
        return $this->hasMany(\App\Models\PaymentWebhookLog::class, 'payment_gateway_id');
    }
}