<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Plan extends Model
{
    use HasFactory;
        protected $table = 'plans';
        protected $fillable = ['name', 'slug', 'code', 'description', 'type', 'billing_period', 'billing_interval', 'is_active', 'is_visible', 'sort_order', 'is_featured', 'metadata', 'created_by', 'updated_by'];

    //handleFileUpload
    

    public function subscriptionOrderItems()
    {
        return $this->hasMany(\App\Models\SubscriptionOrderItem::class, 'plan_id');
    }

    public function subscriptions()
    {
        return $this->hasMany(\App\Models\Subscription::class, 'plan_id');
    }
}