<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PlanFeature extends Model
{
    use HasFactory;
        protected $table = 'plan_features';
        protected $fillable = ['plan_id', 'feature_id', 'value', 'config', 'sort_order', 'is_inherited', 'parent_feature_id', 'effective_from', 'effective_to', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function plan()
    {
        return $this->belongsTo(\App\Models\Plan::class, 'plan_id');
    }

    public function feature()
    {
        return $this->belongsTo(\App\Models\Feature::class, 'feature_id');
    }
}