<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SubscriptionEvent extends Model
{
    use HasFactory;
        protected $table = 'subscription_events';
        protected $fillable = ['subscription_id', 'type', 'data', 'changes', 'causer_id', 'causer_type', 'ip_address', 'user_agent', 'metadata', 'occurred_at', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function subscription()
    {
        return $this->belongsTo(\App\Models\Subscription::class, 'subscription_id');
    }
}