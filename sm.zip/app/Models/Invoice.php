<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Invoice extends Model
{
    use HasFactory;
        protected $table = 'invoices';
        protected $fillable = ['user_id', 'subscription_id', 'number', 'external_id', 'type', 'status', 'subtotal', 'tax', 'total', 'amount_due', 'amount_paid', 'amount_remaining', 'currency', 'issue_date', 'due_date', 'paid_at', 'finalized_at', 'line_items', 'tax_rates', 'discounts', 'metadata', 'history', 'pdf_url', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function subscription()
    {
        return $this->belongsTo(\App\Models\Subscription::class, 'subscription_id');
    }

    public function paymentChildrens()
    {
        return $this->hasMany(\App\Models\PaymentChild::class, 'invoice_id');
    }

    public function payments()
    {
        return $this->hasMany(\App\Models\Payment::class, 'invoice_id');
    }
}