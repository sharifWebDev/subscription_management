<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class RateLimit extends Model
{
    use HasFactory;
        protected $table = 'rate_limits';
        protected $fillable = ['subscription_id', 'feature_id', 'key', 'max_attempts', 'decay_seconds', 'remaining', 'resets_at', 'created_by', 'updated_by'];

    //handleFileUpload
    


public function subscription()
    {
        return $this->belongsTo(\App\Models\Subscription::class, 'subscription_id');
    }

    public function feature()
    {
        return $this->belongsTo(\App\Models\Feature::class, 'feature_id');
    }
}