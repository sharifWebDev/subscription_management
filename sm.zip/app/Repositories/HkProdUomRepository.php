<?php

namespace App\Repositories;

use App\Models\HkProdUom;
use Illuminate\Database\Eloquent\Builder;
use App\Repositories\Contracts\HkProdUomRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class HkProdUomRepository extends BaseRepository implements HkProdUomRepositoryInterface
{
    public function __construct(HkProdUom $hk_prod_uom)
    {
        parent::__construct($hk_prod_uom);
    }

    public function findByEmail(string $email): ?Model
    {
        return $this->model->where('email', $email)->first();
    }
        
    public function export(Request $request): Builder
    {
        return $this->model->newQuery();
    }
}
