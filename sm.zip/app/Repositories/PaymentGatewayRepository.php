<?php

namespace App\Repositories;

use App\Models\PaymentGateway;
use Illuminate\Database\Eloquent\Builder;
use App\Repositories\Contracts\PaymentGatewayRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class PaymentGatewayRepository extends BaseRepository implements PaymentGatewayRepositoryInterface
{
    public function __construct(PaymentGateway $payment_gateway)
    {
        parent::__construct($payment_gateway);
    }

    public function findByEmail(string $email): ?Model
    {
        return $this->model->where('email', $email)->first();
    }
        
    public function export(Request $request): Builder
    {
        return $this->model->newQuery();
    }
}
