<?php

namespace App\Repositories\Contracts;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use \Illuminate\Database\Eloquent\Builder;

interface FeatureRepositoryInterface extends BaseRepositoryInterface
{
    public function findByEmail(string $email): ?Model;
    public function export(Request $request): Builder;
}
