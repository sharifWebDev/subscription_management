<?php

namespace App\Repositories;

use App\Models\Feature;
use Illuminate\Database\Eloquent\Builder;
use App\Repositories\Contracts\FeatureRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class FeatureRepository extends BaseRepository implements FeatureRepositoryInterface
{
    public function __construct(Feature $feature)
    {
        parent::__construct($feature);
    }

    public function findByEmail(string $email): ?Model
    {
        return $this->model->where('email', $email)->first();
    }
        
    public function export(Request $request): Builder
    {
        return $this->model->newQuery();
    }
}
