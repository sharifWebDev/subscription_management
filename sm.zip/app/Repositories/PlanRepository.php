<?php

namespace App\Repositories;

use App\Models\Plan;
use Illuminate\Database\Eloquent\Builder;
use App\Repositories\Contracts\PlanRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class PlanRepository extends BaseRepository implements PlanRepositoryInterface
{
    public function __construct(Plan $plan)
    {
        parent::__construct($plan);
    }

    public function findByEmail(string $email): ?Model
    {
        return $this->model->where('email', $email)->first();
    }
        
    public function export(Request $request): Builder
    {
        return $this->model->newQuery();
    }
}
