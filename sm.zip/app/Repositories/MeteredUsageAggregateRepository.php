<?php

namespace App\Repositories;

use App\Models\MeteredUsageAggregate;
use Illuminate\Database\Eloquent\Builder;
use App\Repositories\Contracts\MeteredUsageAggregateRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class MeteredUsageAggregateRepository extends BaseRepository implements MeteredUsageAggregateRepositoryInterface
{
    public function __construct(MeteredUsageAggregate $metered_usage_aggregate)
    {
        parent::__construct($metered_usage_aggregate);
    }

    public function findByEmail(string $email): ?Model
    {
        return $this->model->where('email', $email)->first();
    }
        
    public function export(Request $request): Builder
    {
        return $this->model->newQuery();
    }
}
