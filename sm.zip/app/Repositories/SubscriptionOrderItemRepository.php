<?php

namespace App\Repositories;

use App\Models\SubscriptionOrderItem;
use Illuminate\Database\Eloquent\Builder;
use App\Repositories\Contracts\SubscriptionOrderItemRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class SubscriptionOrderItemRepository extends BaseRepository implements SubscriptionOrderItemRepositoryInterface
{
    public function __construct(SubscriptionOrderItem $subscription_order_item)
    {
        parent::__construct($subscription_order_item);
    }

    public function findByEmail(string $email): ?Model
    {
        return $this->model->where('email', $email)->first();
    }
        
    public function export(Request $request): Builder
    {
        return $this->model->newQuery();
    }
}
